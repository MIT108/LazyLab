
<?php /**PATH K:\applications\lazy lap\resources\views/layouts/footers/auth/footer.blade.php ENDPATH**/ ?>